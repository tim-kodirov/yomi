<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wanted extends Model
{
    protected $table = 'wanted';

}
