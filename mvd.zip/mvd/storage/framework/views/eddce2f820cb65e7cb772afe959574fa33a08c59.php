<?php $__env->startSection('title', '| Вопросы'); ?>

<?php $__env->startSection('content'); ?>


<div class="pull-right margin-top-20">

	<select name = "is_citizen" class = "news-type-select">
		<option value = "1" <?php echo e($is_citizen ? 'selected' : ''); ?>><?php echo e(__('app.citizen_question')); ?></option>
		<option value = "0" <?php echo e($is_citizen ? '' : 'selected'); ?>><?php echo e(__('app.employee_question')); ?></option>
	</select>
</div>

<h1 class = "text-center"><?php echo e(__('app.nav_questions')); ?></h1>
<hr>

<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="well <?php echo e(Session::has('questions'.$question->id) ? 'question-not-seen' : ''); ?>">
	<div class="row">
		<div class="col-md-8">
			<p>
				<?php echo e($question->question); ?>

				<!-- <?php echo e(mb_substr($question->question, 0, 100)); ?><span id = "<?php echo e("read-more".$question->id); ?>" class = "collapse"><?php echo e(mb_substr($question->question, 100)); ?></span><a href="#" data-toggle="collapse" data-target = "<?php echo e("#read-more".$question->id); ?>">Читать полностью</a> -->
			</p>
			
			<?php if($question->answer != null): ?>
			<p>
				<b data-toggle = "collapse" data-target = "<?php echo e("#answer".$question->id); ?>"><?php echo e(App::isLocale('ru') ? 'Ответ' : 'Жавоб'); ?> <span class = "glyphicon glyphicon-triangle-bottom"></span></b>
				<br>
				<span class = "collapse" id = "<?php echo e("answer".$question->id); ?>">
					<?php echo e($question->answer); ?>

				</span>
			</p>
			<?php endif; ?>
			<div id = "<?php echo e("myAnswer".$question->id); ?>" class = "collapse">
				<?php echo e(Form::open(['route'=> ['questions.answer', $question->id]])); ?>

					<div class="form-group">
						<?php echo e(Form::label('answer', __('app.answer').': ', ['class' => 'control-label'])); ?>

						<?php echo e(Form::textarea('answer', $question->answer!=null ? $question->answer : null, ['class' => 'form-control'])); ?>

					</div>

					<div class = "form-group">
						<?php echo e(Form::submit( __('app.answer'), ['class' => 'btn btn-success'])); ?>

					</div>
					
				<?php echo e(Form::close()); ?>

			</div>
		</div>
		<div class="col-md-4">
			<table class = "table">
				<tr>
					<th><?php echo e(__('app.author')); ?>: </th>
					<th><?php echo e($question->last_name); ?> <?php echo e($question->first_name); ?> <?php echo e($question->middle_name); ?></th>
				</tr>
				<tr>
					<th>Номер: </th>
					<td><?php echo e($question->phone_number); ?></td>
				</tr>

				<tr>
					<td><?php echo e(__('app.created')); ?>: </td>
					<td><?php echo e(date('d.m.Y, h:i', strtotime($question->created_at))); ?></td>
				</tr>
				<tr>
					<td><?php echo e(__('app.updated')); ?>: </td>
					<td><?php echo e(date('d.m.Y, h:i', strtotime($question->updated_at))); ?></td>
				</tr>
				<tr>
					<td colspan="2">
						<button type="button" class="btn btn-success" data-toggle="collapse" data-target="<?php echo e("#myAnswer".$question->id); ?>"><?php echo e(__('app.answer')); ?></button>

						<span class = "pull-right">
							<button class = "btn btn-sm btn-primary" data-toggle="modal" data-target = "<?php echo e("#myEdit".$question->id); ?>"><span class = "glyphicon glyphicon-edit"></span></button>
							<button class = "btn btn-sm btn-danger" data-toggle ="modal" data-target = <?php echo e("#myDelete"."$question->id"); ?>><span class = "glyphicon glyphicon-trash"></span></button>
						</span>
					</td>
				</tr>
			</table>

			<div id="<?php echo e("myEdit".$question->id); ?>" class="modal fade" role="dialog">
			  <div class="modal-dialog">

			    <!-- Modal content-->
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal">&times;</button>
			        <h4 class="modal-title text-center"><?php echo e(__('app.change')); ?></h4>
			      </div>
			      <div class="modal-body">
			      	<?php echo e(Form::model($question, ['route' => ['questions.update', $question->id], 'method' => 'PUT'])); ?>

			        <div class="row">
			        	<div class = "col-md-12">
			        		
			        		<div class="form-group">
								<?php echo e(Form::label('first_name', __('app.f_name').': ')); ?>

								<?php echo e(Form::text('first_name', null,['class' => 'form-control'])); ?>

							</div>

							<div class="form-group">
								<?php echo e(Form::label('last_name', __('app.s_name').': ')); ?>

								<?php echo e(Form::text('last_name', null,['class' => 'form-control'])); ?>

							</div>

							<div class="form-group">
								<?php echo e(Form::label('middle_name', __('app.m_name').': ')); ?>

								<?php echo e(Form::text('middle_name', null,['class' => 'form-control'])); ?>

							</div>

							<div class="form-group">
								<?php echo e(Form::label('phone_number', 'Номер: ')); ?>

								<?php echo e(Form::text('phone_number', null,['class' => 'form-control'])); ?>

							</div>
							
							<div class="form-group">
								<?php echo e(Form::label('address', 'Адресс: ')); ?>

								<?php echo e(Form::text('address', null, ['class' => 'form-control'])); ?>

							</div>

							<div class="form-group">
								<?php echo e(Form::label('question', __('app.question').': ')); ?>

								<?php echo e(Form::textarea('question', null,['class' => 'form-control'])); ?>

							</div>

							<div class="form-group">
								<label class = "radio-inline">
								<?php echo e(Form::radio('is_citizen', 1, ['class' => 'form-control'])); ?>

								<?php echo e(__('app.citizen_question')); ?>

								</label>

								<label class = "radio-inline">
								<?php echo e(Form::radio('is_citizen', 0, ['class' => 'form-control'])); ?>

								<?php echo e(__('app.employee_question')); ?>

								</label>
							</div>

			        	</div>
			        </div>	
			        <div class = "row">
			        	<div class="col-md-6">
							<div class = "form-group">
								<?php echo e(Form::submit(__('app.change'), ['class' => 'btn btn-danger btn-block'])); ?>

							</div>
							
			        	</div>
			        	<div class="col-md-6">
			        		<button type="button" class="btn btn-block btn-success" data-dismiss="modal"><?php echo e(__('app.cancel')); ?></button>
			        	</div>
			        	
			        </div>
			        <?php echo e(Form::close()); ?>

			      </div>
		
			    </div>

			  </div>
			</div>

			<div id=<?php echo e("myDelete"."$question->id"); ?> class="modal fade" role="dialog">
				<div class="modal-dialog">
					
				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
				      </div>
				      <div class="modal-body">
				      	<div class = "row">
				      		<div class = "col-md-6">
					        	<?php echo Form::open(['route' => ['questions.destroy', $question->id ], 'method' => "delete"]); ?>

					        		<?php echo e(Form::submit(__('app.yes'), ['class' => 'btn btn-success btn-large btn-block'])); ?>

					        	<?php echo Form::close(); ?>

					        </div>

					        <div class = "col-md-6">
					        	<button type="button" class="btn btn-danger btn-large btn-block" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
					        </div>
				      	</div>
				        
				      </div>
				    </div>

				</div>
			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$('.news-type-select').change(function()
			{	
				var val = $(this).val();
				window.location.replace('/admin/questions?is_citizen='+val);
			});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>