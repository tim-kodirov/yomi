<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<header id = "my-header">
  <div class="container-fluid">
    <div class="container">
      <div class="row">
        <div class = "col-sm-4">
          <div class="row margin-top-20">
            <?php echo e(Form::open(['route' => 'lang', 'class' => 'pull-left margin-right', 'id' => 'ru-submit'])); ?>

              <input type = "hidden" name = "lang" value = "ru"/>
              <a type = "submit" onclick = "document.getElementById('ru-submit').submit();" class = "<?php echo e(App::isLocale('ru') ? "my-btn-active" : ""); ?> my-btn btn btn-default"><b>Рус</b></a>
            <?php echo e(Form::close()); ?>


            <?php echo e(Form::open(['route' => 'lang', 'class' => 'pull-left', 'id' => 'uz-submit'])); ?>

              <input type = "hidden" name = "lang" value = "uz"/>
              <a type = "submit" onclick = "document.getElementById('uz-submit').submit();" class = "<?php echo e(App::isLocale('uz') ? "my-btn-active" : ""); ?> my-btn btn btn-default"><b>Ўзб</b></a>
            <?php echo e(Form::close()); ?>


          </div><!-- end of ru/uz -->

          <div class = "row margin-top-20">
            <div class="input-group search-group">
              <input type = "text" placeholder="<?php echo e(__('app.search')); ?>..." class = "form-control search"/>
              <div class="input-group-btn">
                <button class="btn btn-default" type="submit">
                  <i class="glyphicon glyphicon-search"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class = "col-sm-3 col-xs-12 text-center">
            <img id="logogo" src="images/gerb1.png" alt="Logo">
        </div>

        <div class="col-sm-5"> 
<div class="col-sm-9">
    <p id="demo"></p>
    <br>
          <div class="pull-right hidden-xs">
                <h4><span class="glyphicon glyphicon-phone-alt"></span> <?php echo e(__('app.save_service')); ?>: 289 99 99</h4>

                <h4><span class="glyphicon glyphicon-earphone"></span> <?php echo e(__('app.trust_call')); ?>: 5555</h4>
          </div>
</div>

</div>
        </div>
        
      </div><!-- end of header row-->
    </div>
    <div class="container">
    <h2 class = "text-center margin-top-0"> <b><?php echo e(__('app.dep_name_part_2')); ?></b></h2>
    </div>
        <br>
  </div>

</header><!-- end of header-->




