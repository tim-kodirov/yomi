<?php $__env->startSection('title', '| Видео'); ?>

<?php $__env->startSection('content'); ?>

	<h1 class = "text-center"><?php echo e(__('app.videos')); ?></h1>
	<hr>
	<div class="row">
		<div class="col-md-8">
			<div class="row">
			<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-6">
					<video width = "100%" controls>
						<source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/mp4">
						<source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/ogg">
						<source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/webm">
					</video>

					<p class = "info margin-top">
						<?php echo e(__('app.created')); ?>: <span class = "pull-right"><?php echo e(date("d.m.y, H:i", strtotime($video->created_at))); ?></span>
							<br>
					</p>
					<p class = "text-right">
						<button class = "btn btn-danger btn-sm" data-toggle="modal" data-target="<?php echo e("#myDelete".$video->id); ?>"><span class = "glyphicon glyphicon-trash"></span></button>

						<div id="<?php echo e("myDelete".$video->id); ?>" class="modal fade" role="dialog">
						  <div class="modal-dialog">

						    <!-- Modal content-->
						    <div class="modal-content">
						      <div class="modal-header">
						        
						        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
						      </div>
						      <div class="modal-body">
						        <div class="row">
						        	<div class="col-md-6">
						        		<?php echo e(Form::open(['route' => ['videos.destroy', $video->id ], 'method' => 'DELETE'])); ?>

											<?php echo e(Form::submit( __('app.yes'), ['class' => 'btn btn-block btn-danger'])); ?>

						        		<?php echo e(Form::close()); ?>

						        	</div>
						        	<div class="col-md-6">
						        		<button type="button" class="btn btn-block btn-success" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
						        	</div>
						        </div>
						      </div>
					
						    </div>

						  </div>
						</div>
					</p>
					<h4 class = "text-center">
							<?php echo e(App::isLocale('uz') ? $video->title_uz : $video->title_ru); ?>

						</h4>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<div class="text-center">
				<?php echo e($videos->links()); ?>

			</div>
		</div>
		<div class="col-md-4">
			<div class = "panel panel-default">
				<div class = "panel-heading text-center">
					<h3 class = "margin"><?php echo e(__('app.create')); ?></h3>
				</div>

				<div class = "panel-body">
					<?php echo e(Form::open(['route' => 'videos.store', 'files' => 'true'])); ?>

						<div class = "form-group">
							<?php echo e(Form::file('video')); ?>

						</div>

						<div class = "form-group">
							<?php echo e(Form::label('title_uz', 'Сарлавха(узб): ', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('title_uz', null, ['class' => 'form-control'])); ?>

							
						</div>

						<div class = "form-group">
							<?php echo e(Form::label('title_ru', 'Заглавие(рус): ', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('title_ru', null, ['class' => 'form-control'])); ?>

							
						</div>

						<div class = "form-group">
							<?php echo e(Form::submit( __('app.create'), ['class' => 'btn btn-success btn-block'])); ?>

						</div>
					<?php echo e(Form::close()); ?>

				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>