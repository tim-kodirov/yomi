<?php $__env->startSection('title', '| '.$news->title_uz); ?>

<?php $__env->startSection('content'); ?>

<h2 class = "text-center color-title"><?php echo e(App::isLocale('ru') ? $news->title_ru : $news->title_uz); ?></h2>
<hr>
<h4><b><?php echo e(App::isLocale('ru') ? $news->overview_ru : $news->overview_uz); ?></b></h4>
<br>
<p><img src="<?php echo e(asset("images/".$news->image)); ?>" width = "100%"></p>
<br>
<p><?php echo App::isLocale('ru') ? $news->body_ru : $news->body_uz; ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>