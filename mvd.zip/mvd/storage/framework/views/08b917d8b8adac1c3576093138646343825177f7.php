<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>

<h2 class = "color-title"><?php echo e(__('app.department_system')); ?></h2>
<hr>
<img src="<?php echo e(asset('images/tizim.png')); ?>" width = "100%">

<br>
<br>
     
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

<?php echo $__env->make('partials._department_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>