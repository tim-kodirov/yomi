<?php $__env->startSection('title', '| Создать'); ?>

<?php $__env->startSection('content'); ?>

<h1 class = "text-center">
<a href = "<?php echo e(route('news.index')); ?>" class = "btn btn-large btn-primary pull-left"><span class = "glyphicon glyphicon-arrow-left"></span></a>
<?php echo e(__('app.create')); ?></h1>
<hr>
<?php echo e(Form::open(['route' => 'news.store', 'class' => 'form-horizontal', 'files' => 'true'])); ?>


	<div class="row">
		<div class="col-md-6">
			<h2 class = "text-center">Узбекча</h2>
			<hr>
			<div class = "form-group">
				<?php echo e(Form::label('title_uz', 'Сарлавха:', ['class' => 'col-md-2'])); ?>

				<div class = "col-md-10">
					<?php echo e(Form::text('title_uz', null, ['class' => 'form-control'])); ?>

				</div>
			</div>

			<div class = "form-group">
				<?php echo e(Form::label('overview_uz', 'Тавсиф:', ['class' => 'col-md-2'])); ?>

				<div class = "col-md-10">
					<?php echo e(Form::text('overview_uz', null, ['class' => 'form-control'])); ?>

				</div>
			</div>

			<div class = "form-group">
				<?php echo e(Form::label('body_uz', 'Контент:', ['class' => 'col-md-2'])); ?>

				<div class = "col-md-10">
					<?php echo e(Form::textarea('body_uz', null, ['class' => 'form-control', 'rows' => '30'])); ?>

				</div>
			</div>
		</div>
		<div class="col-md-6">
			<h2 class = "text-center">Русский</h2>
			<hr>
			<div class = "form-group">
				<?php echo e(Form::label('title_ru', 'Заглавие:', ['class' => 'col-md-2'])); ?>

				<div class = "col-md-10">
					<?php echo e(Form::text('title_ru', null, ['class' => 'form-control'])); ?>

				</div>
			</div>

			<div class = "form-group">
				<?php echo e(Form::label('overview_ru', 'Описание:', ['class' => 'col-md-2'])); ?>

				<div class = "col-md-10">
					<?php echo e(Form::text('overview_ru', null, ['class' => 'form-control'])); ?>

				</div>
			</div>

			<div class = "form-group">
				<?php echo e(Form::label('body_ru', 'Контент:', ['class' => 'col-md-2'])); ?>

				<div class = "col-md-10">
					<?php echo e(Form::textarea('body_ru', null, ['class' => 'form-control', 'rows' => '30'])); ?>

				</div>
			</div>
		</div>
	</div>
	

	<div class = "form-group">
		<?php echo e(Form::label('image', 'Картина:', ['class' => 'col-md-1'])); ?>

		<div class = "col-md-11">
			<?php echo e(Form::file('image', null, ['class' => 'form-control'])); ?>

		</div>
	</div>

	<div class = "form-group">
		<div class = "col-md-11 col-md-offset-1">
			<label class = "radio-inline"><?php echo e(Form::radio('isDepartment', 0, true)); ?> Обычная новость</label>
			<label class = "radio-inline"><?php echo e(Form::radio('isDepartment', 1)); ?> Про департамент</label>
		</div>
	</div>

	
		<?php echo e(Form::submit( __('app.create'), ['class' => 'btn btn-success btn-lg btn-block'])); ?>

	
	
	

<?php echo e(Form::close()); ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

	<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=a0p04bn5ynhonmwd7qcym2qju26ass5qtbrchg8wx7a6xv41"></script>
	<script>tinymce.init(
	{ 
		selector:'textarea' 		
	});
	</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>