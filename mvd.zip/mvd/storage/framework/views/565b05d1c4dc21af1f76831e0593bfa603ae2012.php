<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>

<h2 class = "color-title">Эксперт-криминалистика бош бошқармаси</h2>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
    
     <br>
     <br>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

<div class="characters">
		<h2 class = "text-center">Департамент хақида</h2>
	</div>
	<br>
    <div class="row text-center"> 
      <a href=""><h4>Департамент тарихи</h4></a>
      <hr>
      <a href=""><h4>Департамент рахбарияти</h4></a>
      <hr>
      <a href=""><h4>Департамент тизими</h4></a>
      <hr>
      <a href=""><h4>Эксперт-криминалистика бош <br>бошкармаси</h4></a>
      <hr>
      <a href=""><h4>Ахборот маркази</h4></a>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>