<?php $__env->startSection('title', '| Документы'); ?>

<?php $__env->startSection('content'); ?>

<h1 class = "text-center">
	<?php echo e(__('app.nav_documents')); ?>

	<a href = "<?php echo e(route('documents.create')); ?>" class = "btn btn-lg btn-primary pull-right"><?php echo e(__('app.create')); ?></a>
</h1>
<hr>
<div class="row">
	<div class="col-md-8">
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<p class = "overflow-hidden">
				<span class = "pull-right">
					<button class = "btn btn-sm btn-primary" data-toggle="modal" data-target = "<?php echo e("#myEdit".$category->id); ?>"><span class = "glyphicon glyphicon-edit"></span></button>
					<button class = "btn btn-danger btn-sm" data-toggle="modal" data-target="<?php echo e("#myDelete".$category->id); ?>"><span class = "glyphicon glyphicon-trash"></span></button>
				</span>
				<b><?php echo e(App::isLocale('uz') ? $category->category_uz : $category->category_ru); ?></b>
			</p>
			<div id="<?php echo e("myEdit".$category->id); ?>" class="modal fade" role="dialog">
			  <div class="modal-dialog">

			    <!-- Modal content-->
			    <div class="modal-content">
			      <div class="modal-header">
			        
			        <h4 class="modal-title text-center"><?php echo e(App::isLocale('uz') ? "Категорияни озрагтириш" : "Изменить подраздел(категорию)"); ?></h4>
			      </div>
			      <div class="modal-body">
			        <div class="row">
			        	<div class = "col-md-12">
			        		<?php echo e(Form::model($category, ['route' => ['categories.update', $category->id], 'method' => 'PUT'])); ?>

			        		<div class = "form-group">
								<?php echo e(Form::label('category_uz', 'Номи:')); ?>

								<?php echo e(Form::text('category_uz', null, ['class' => 'form-control'])); ?>

							</div>
	
							<div class = "form-group">
								<?php echo e(Form::label('category_ru', 'Название:')); ?>

								<?php echo e(Form::text('category_ru', null, ['class' => 'form-control'])); ?>

							</div>
			        	</div>
			        </div>	
			        <div class = "row">
			        	<div class="col-md-6">
							<div class = "form-group">
								<?php echo e(Form::submit( __('app.change'), ['class' => 'btn btn-danger btn-block'])); ?>

							</div>
							
			        	</div>
			        	<div class="col-md-6">
			        		<button type="button" class="btn btn-block btn-success" data-dismiss="modal"><?php echo e(__('app.cancel')); ?></button>
			        	</div>
			        	<?php echo e(Form::close()); ?>

			        </div>
			      </div>
		
			    </div>

			  </div>
			</div>
			<div id="<?php echo e("myDelete".$category->id); ?>" class="modal fade" role="dialog">
			  <div class="modal-dialog">

			    <!-- Modal content-->
			    <div class="modal-content">
			      <div class="modal-header">
			        
			        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
			      </div>
			      <div class="modal-body">
			        <div class="row">
			        	<div class="col-md-6">
			        		<?php echo e(Form::open(['route' => ['categories.destroy', $category->id ], 'method' => 'DELETE'])); ?>

								<?php echo e(Form::submit(__('app.yes'), ['class' => 'btn btn-block btn-danger'])); ?>

			        		<?php echo e(Form::close()); ?>

			        	</div>
			        	<div class="col-md-6">
			        		<button type="button" class="btn btn-block btn-success" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
			        	</div>
			        </div>
			      </div>
		
			    </div>

			  </div>
			</div>
			<ul>
				<?php $__currentLoopData = $category->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class = "overflow-hidden document-list-item">
						<span class = "pull-right">
							<a href = "<?php echo e(route('documents.edit', $document->id)); ?>" class = "btn btn-sm btn-primary"><span class = "glyphicon glyphicon-edit"></span></a>
							<button class = "btn btn-sm btn-danger" data-toggle ="modal" data-target = <?php echo e("#docDelete"."$document->id"); ?>><span class = "glyphicon glyphicon-trash"></span></button>
						</span>
						<div id=<?php echo e("docDelete"."$document->id"); ?> class="modal fade" role="dialog">
							<div class="modal-dialog">
								
							    <!-- Modal content-->
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal">&times;</button>
							        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
							      </div>
							      <div class="modal-body">
							      	<div class = "row">
							      		<div class = "col-md-6">
								        	<?php echo Form::open(['route' => ['documents.destroy', $document->id ], 'method' => "delete"]); ?>

								        		<?php echo e(Form::submit(__('app.yes'), ['class' => 'btn btn-success btn-large btn-block'])); ?>

								        	<?php echo Form::close(); ?>

								        </div>

								        <div class = "col-md-6">
								        	<button type="button" class="btn btn-danger btn-large btn-block" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
								        </div>
							      	</div>
							        
							      </div>
							    </div>

							</div>
						</div>
						<a href="<?php echo e(route('documents.show', $document->id)); ?>">
							<?php echo e(App::isLocale('uz') ? $document->title_uz : $document->title_ru); ?>

						</a>
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div class="col-md-4">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class = "text-center margin"><?php echo e(App::isLocale('uz') ? "Категорияни киргизищ" : "Добавить подраздел(категорию)"); ?></h3>
			</div>

			<div class="panel-body">
				<?php echo e(Form::open(['route' => 'categories.store'])); ?>

					<div class="form-group">
						<?php echo e(Form::label('category_uz', 'Номи:')); ?>

						<?php echo e(Form::text('category_uz', null, ['class' => 'form-control'])); ?>

					</div>

					<div class="form-group">
						<?php echo e(Form::label('category_ru', 'Название:')); ?>

						<?php echo e(Form::text('category_ru', null, ['class' => 'form-control'])); ?>

					</div>

					<div class = "form-group">
						<?php echo e(Form::submit(__('app.create'), ['class' => 'btn btn-success btn-block'])); ?>

					</div>
				<?php echo e(Form::close()); ?>

			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>