<?php $__env->startSection('title', '| Галарея'); ?>

<?php $__env->startSection('styles'); ?>
	<link href="<?php echo e(asset("css/lightbox.css")); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h2>Галерея</h2>
<hr>
    
    <ul class="nav nav-pills">
      <li class="<?php echo e(Request::is('gallery/0') ? 'active' : ''); ?>"><a href="<?php echo e(route('gallery', 0)); ?>"><?php echo e(__('app.photos')); ?></a></li>
      <li class="<?php echo e(Request::is('gallery/1') ? 'active' : ''); ?>"><a href="<?php echo e(route('gallery', 1)); ?>"><?php echo e(__('app.videos')); ?></a></li>
    </ul>
    <br>
    <?php if(Request::is('gallery/0')): ?>
    <div class="row">
        
    	<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4 photo-list">
            <div class="thumbnail">
                <a data-lightbox ="<?php echo e("image".$photo->id); ?>" href="<?php echo e(asset('images/'.$photo->photo)); ?>">
                    <img src="<?php echo e(asset('images/'.$photo->photo)); ?>" alt="Park">
                <div class="caption">
                    <p class = "margin-0 text-center"><b><?php echo e(App::isLocale('ru') ? $photo->title_ru : $photo->title_uz); ?></b></p>
                </div>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>

    <?php echo $photos->links(); ?>

    <?php endif; ?>

    <?php if(Request::is('gallery/1')): ?>
    <div class="row">
        
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 video-list text-center">
            <video controls width = "100%">
              <source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/mp4">
              <source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/ogg">
              <source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/webm">
            </video>
            <h4><?php echo e(App::isLocale('ru') ? $video->title_ru : $video->title_uz); ?></h4>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>

    <?php echo $videos->links(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>