<?php $__env->startSection('title', "| Новость ".$news->id); ?>


<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('news.index')); ?>" class = "pull-left btn btn-primary">
	<span class = "glyphicon glyphicon-arrow-left"></span>
</a> 
<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<h2 class = "color-title"><?php echo e(App::isLocale('uz') ? $news->title_uz : $news->title_ru); ?></h2>
		<h3><b><?php echo e(App::isLocale('uz') ? $news->overview_uz : $news->overview_ru); ?></b></h3>
		<br>

		<img src= "<?php echo e(asset('images/'.$news->image)); ?>" class = "img-responsive" width = "100%">
		<p class = "info margin-top">
			<?php echo e(__('app.created')); ?>: <?php echo e(date('d.m.y, h:i', strtotime($news->created_at))); ?>

			</br>
			<?php echo e(__('app.updated')); ?>: <?php echo e(date('d.m.y, h:i', strtotime($news->updated_at))); ?>

		</p>

				
		<hr>
			

		<div class = "body">
			<?php echo App::isLocale('uz') ? $news->body_uz : $news->body_ru; ?>

		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>