<?php $__env->startSection('title', '| Руководители'); ?>

<?php $__env->startSection('content'); ?>


<div class="pull-right margin-top-20">

	<select name = "region" class = "news-type-select">
		<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value = "<?php echo e($city->id); ?>" <?php echo e($selectedCity->id == $city->id ? 'selected' : ''); ?>><?php echo e(App::isLocale('ru') ? $city->name_ru : $city->name_uz); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>

	<a href = "<?php echo e(route('managers.create')); ?>" class = "btn btn-lg btn-primary"><?php echo e(__('app.create')); ?></a>
</div>

<h1 class = "text-center"><?php echo e(__('app.department_managers')); ?></h1>
<hr>

<div class="row">
	<div class="col-md-8 col-md-offset-2">	
		<table class = "table table-striped">
			<thead>	
				<tr>
					<th>№</th>	
					<th><?php echo e(__('app.image')); ?></th>
					<th><?php echo e(__('app.manager_info')); ?></th>
					<th>Тел</th>
					<th><?php echo e(__('app.manager_admission')); ?></th>
					<th>Адресс</th>
					<th></th>
				</tr>
			</thead>

			<tbody>
				<?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th><?php echo e($manager->id); ?></th>
					<td><img src="<?php echo e(asset('images/managers/'.$manager->image)); ?>" height = "200px"></td>
					<td><?php echo e(App::isLocale('ru') ? $manager->info_ru : $manager->info_uz); ?></td>
					<td><?php echo e($manager->contact); ?></td>
					<td><?php echo e(App::isLocale('ru') ? $manager->admission_days_ru : $manager->admission_days_uz); ?></td>
					<td><?php echo e(App::isLocale('ru') ? $manager->address_uz : $manager->address_ru); ?></td>
					<td>
						<a href = "<?php echo e(route('managers.edit', $manager->id)); ?>" class = "btn btn-info btn-sm"><span class = "glyphicon glyphicon-pencil"></span></a>

						<button data-toggle = "modal" data-target = "<?php echo e("#delete".$manager->id); ?>" class = "btn btn-danger btn-sm margin-top"><span class = "glyphicon glyphicon-trash"></span></button>

						<div id=<?php echo e("delete"."$manager->id"); ?> class="modal fade" role="dialog">
							<div class="modal-dialog">
								
							    <!-- Modal content-->
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal">&times;</button>
							        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
							      </div>
							      <div class="modal-body">
							      	<div class = "row">
							      		<div class = "col-md-6">
								        	<?php echo Form::open(['route' => ['managers.destroy', $manager->id ], 'method' => "delete"]); ?>

								        		<?php echo e(Form::submit(__('app.yes'), ['class' => 'btn btn-success btn-large btn-block'])); ?>

								        	<?php echo Form::close(); ?>

								        </div>

								        <div class = "col-md-6">
								        	<button type="button" class="btn btn-danger btn-large btn-block" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
								        </div>
							      	</div>
							        
							      </div>
							    </div>

							</div>
						</div>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>	
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$('.news-type-select').change(function()
			{	
				var val = $(this).val();
				window.location.replace('/admin/managers?region='+val);
			});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>