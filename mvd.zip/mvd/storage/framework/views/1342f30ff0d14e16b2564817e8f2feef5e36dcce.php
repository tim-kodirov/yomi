<?php $__env->startSection('title', '| Вопросы и Ответы'); ?>

<?php $__env->startSection('content'); ?>

<h2><?php echo e(__('app.nav_questions')); ?></h2>
<hr>
<div class="panel-group" id="accordion">

<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="<?php echo e("#collapse".$question->id); ?>">
        <?php echo e($question->question); ?></a>
      </h4>
    </div>
    <div id="<?php echo e("collapse".$question->id); ?>" class="panel-collapse collapse">
      <div class="panel-body"><?php echo e($question->answer); ?></div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $questions->links(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>