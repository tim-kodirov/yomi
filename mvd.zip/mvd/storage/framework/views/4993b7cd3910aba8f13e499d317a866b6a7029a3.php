<div class="characters">
	<h3 class = "text-center"><?php echo e(__('app.nav_department')); ?></h3>
</div>
<br>
<div class="text-center"> 
  <a href="<?php echo e(route('department', 1)); ?>"><h4><?php echo e(__('app.department_history')); ?></h4></a>
  <hr>
  <a href="<?php echo e(route('department', 2)); ?>"><h4><?php echo e(__('app.department_managers')); ?></h4></a>
  <hr>
  <a href="<?php echo e(route('department', 3)); ?>"><h4><?php echo e(__('app.department_system')); ?></h4></a>
  <hr>
  <a href="<?php echo e(route('department', 4)); ?>"><h4><?php echo e(__('app.department_functions')); ?></h4></a>
  <hr>
  <a href="<?php echo e(route('department', 5)); ?>"><h4><?php echo e(__('app.department_rights')); ?></h4></a>
  <hr>
</div>