<?php $__env->startSection('styles'); ?>
  <link href="<?php echo e(asset("css/lightbox.css")); ?>" rel="stylesheet">

  <link href="https://cdnjs.cloudflare.com/ajax/libs/jqvmap/1.5.1/jqvmap.min.css" media="screen" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset("sliderengine/amazingslider-1.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<ul class="nav nav-pills">
  <li class="active"><a data-toggle="tab" href="#menu1"><b> ФОТО </b></a></li>
  <li><a data-toggle="tab" href="#menu2"><b> ВИДЕО </b></a></li>
</ul>
<br>
<div class="tab-content" >
  <div id="menu1" class="tab-pane fade in active">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
    
      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item <?php echo e($photo == 0 ? "active" : ""); ?> text-center">
            <a data-lightbox ="<?php echo e("image".$value->id); ?>" href="<?php echo e(asset('images/'.$value->photo)); ?>">
            <img src="<?php echo e(asset("images/".$value->photo)); ?>" alt="Los Angeles" height="200px">
            <div class="carousel-caption">
              <p><?php echo e(App::isLocale('ru') ? $value->title_ru : $value->title_uz); ?></p>
            </div>
            </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    
      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
   
  </div>
  <div id="menu2" class="tab-pane fade">
    <video controls width = "100%">
      <source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/mp4">
      <source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/ogg">
      <source src="<?php echo e(asset('storage/videos/'.$video->video)); ?>" type="video/webm">
    </video>
  </div>
</div>

<?php if(Session::has('question_sent')): ?>
  <div class="alert alert-success margin-top-20">
    <?php echo e(Session::get('question_sent')); ?>

  </div>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger margin-top-20">
  <ul>
    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li> <?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>
<div class="alert alert-info text-center margin-top-20">
  <div class="row">
    <div class = "col-sm-4 btn-grp">
      <button data-toggle="modal" data-target="#myModal" class="btn btn-darkblue btn-lg btn-block" role="button"><?php echo e(__('app.online_service')); ?></button>
    </div>

    <div class = "col-sm-4 btn-grp">
      <div class="dropdown no-padding">
        <button data-toggle="dropdown" class="btn btn-darkblue btn-lg btn-block"><?php echo e(__('app.admission_service')); ?> <span class="caret"></span></button>

        <ul class="dropdown-menu">
          <li><a data-toggle = "modal" href="#myDateModal_1" role = "button"><?php echo e(__('app.department_managers')); ?></a></li>
          <li><a data-toggle = "modal" href="#myDateModal_2" role = "button"><?php echo e(__('app.region_managers')); ?></a></li>
        </ul>
      </div>
      
    </div>

    <div class = "col-sm-4 btn-grp">
      <a href="<?php echo e(route('questions')); ?>" class="btn btn-darkblue btn-lg btn-block" role="button"><?php echo e(__('app.nav_questions')); ?></a>
    </div>
  </div>
  <strong>
  
  
  
  </strong> 
</div>



<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">
      <?php echo Form::open(['route' => 'questions.store']); ?>

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo e(__('app.online_service')); ?></h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="first_name"><?php echo e(__('app.f_name')); ?>:</label>
          <input type="text" class="form-control" id="first_name" name="first_name">
        </div>
        <div class="form-group">
          <label for="last_name"><?php echo e(__('app.s_name')); ?>:</label>
          <input type="text" class="form-control" id="last_name" name="last_name">
        </div>
        <div class="form-group">
          <label for="middle_name"><?php echo e(__('app.m_name')); ?>:</label>
          <input type="text" class="form-control" id="middle_name" name="middle_name">
        </div>
        <div class="form-group">
          <label for="phone_number">Телефон:</label>
          <input type="text" class="form-control" id="phone_number" name="phone_number" placeholder="901234567">
        </div>
        <div class="form-group">
          <label for="address">Адресc:</label>
          <input type="text" class="form-control" id="address" name="address">
        </div>
        <div class="form-group">
          <label for="question"><?php echo e(__('app.question')); ?>:</label>
          <textarea class="form-control" rows="5" id="question" name="question"></textarea>
        </div>
        <div class="form-group">
          <label class = "radio-inline">
            <input type="radio" name="is_citizen" value = "1" checked>
            <?php echo e(__('app.citizen_question')); ?>

          </label>

          <label class = "radio-inline">
            <input type="radio" name="is_citizen" value = "0">
            <?php echo e(__('app.employee_question')); ?>

          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success btn-block"><?php echo e(__('app.send')); ?></button>
      </div>
      <?php echo Form::close(); ?>

    </div>
    
  </div>
</div>

<div class="modal fade" id="myDateModal_1" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo e(__('app.admission_service')); ?></h4>
      </div>
      <div class="modal-body">
        <table class = "table table-bordered table-striped">
          <thead>
            <tr>
              <th>Лавозими</th>
              <th>Ф.И.Ш</th>
              <th>Кабул кунлари</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
  </div>
</div>

<div class="modal fade" id="myDateModal_2" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo e(__('app.admission_service')); ?></h4>
      </div>
      <div class="modal-body">
        <table class = "table table-bordered table-striped">
          <thead>
            <tr>
              <th>Лавозими</th>
              <th>Ф.И.Ш</th>
              <th>Кабул кунлари</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>

            <tr>
              <td>Ички Ишлар Вазирлиги вазири</td>
              <td>Азизов Абдусалом Абдумавлянович</td>
              <td>Душанба, 10.00 дан 12.00 гача</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
  </div>
</div>
  
<h2>
<p class = "pull-right all-news-link margin-top-20"><a href="<?php echo e(route('news', 0)); ?>"><b><?php echo e(__('app.all_news')); ?></b></a></p>
<b><?php echo e(mb_strtoupper(__('app.nav_news'))); ?></b>
</h2>
<hr>
<div class="row">
  <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm-6 news-list-item">
    <div class="panel panel-default">
        <div class="panel-heading">
          <strong><a class="post-title" href="<?php echo e(route('news.single', $new->slug)); ?>">
          <?php echo e(App::isLocale('ru') ? $new->title_ru : $new->title_uz); ?></a></strong>
        </div>
        <div class="panel-body news-list-item-body equal-items">
          <div class="col-md-6">
                <a href="<?php echo e(route('news.single', $new->slug)); ?>" class="thumbnail"><img src="<?php echo e(asset("images/".$new->image)); ?>" alt=""></a>
          </div>     
          <p>
            <?php echo e(App::isLocale('ru') ? $new->overview_ru : $new->overview_uz); ?> 
          </p>
        </div>                  
        <div class="panel-footer">
         <span class="glyphicon glyphicon-calendar"></span> <?php echo e(date('d.m.Y, h:i', strtotime($new->created_at))); ?>

        </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<h2>
<p class = "pull-right margin-top-20 all-news-link"><a href="<?php echo e(route('news', 1)); ?>"><b><?php echo e(__('app.all_news')); ?></b></a></p>
<b><?php echo e(mb_strtoupper(__('app.nav_news_dep'))); ?></b>
</h2>
<hr>
<div class="row">
  <?php $__currentLoopData = $depNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm-6 news-list-item">
    <div class="panel panel-default">
        <div class="panel-heading">
          <strong><a class="post-title" href="<?php echo e(route('news.single', $new->slug)); ?>"><?php echo e(mb_substr(App::isLocale('ru') ? $new->title_ru : $new->title_uz, 0, 30)); ?> <?php echo e(mb_strlen(App::isLocale('ru') ? $new->title_ru : $new->title_uz) > 35 ? '...' : ''); ?></a></strong>
        </div>
        <div class="panel-body news-list-item-body equal-items-next">
          <div class="col-md-6">
                <a href="<?php echo e(route('news.single', $new->slug)); ?>" class="thumbnail"><img src="<?php echo e(asset("images/".$new->image)); ?>" alt=""></a>
          </div>     
          <p>
            <?php echo e(App::isLocale('ru') ? $new->overview_ru : $new->overview_uz); ?>  
          </p>
        </div>                  
        <div class="panel-footer">
         <span class="glyphicon glyphicon-calendar"></span> <?php echo e(date('d.m.Y, h:i', strtotime($new->created_at))); ?>

        </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-content'); ?>

<div id = "world">
  <div id="vmap" style="width: 100%;"></div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqvmap/1.5.1/jquery.vmap.min.js" type="text/javascript"></script>

<script src ="<?php echo e(asset("js/vmap.uzbekistan.js")); ?>" type="text/javascript" ></script>

<script type="text/javascript">
        jQuery(document).ready(function() {
            jQuery('#vmap').vectorMap({ map: 'uzbekistan',
            backgroundColor: 'inherit',
            borderColor: 'white',
            borderOpacity: 0,
            borderWidth: 1,
            color: '#71b9c6',
            enableZoom: false,
            hoverColor: '#42909e',
            hoverOpacity: null,
            normalizeFunction: 'linear',
            scaleColors: ['#b6d6ff', '#005ace'],
            selectedColor: '#42909e',
            selectedRegions: null,
            showTooltip: true,
            onRegionClick: function(element, code, region)
            {
                var message = 'You clicked "'
                    + region
                    + '" which has the code: '
                    + code.toUpperCase();

                alert(message);
            }    
                });
        });
</script>

<script src = "<?php echo e(asset('js/jquery.matchHeight.js')); ?>" type="text/javascript"></script>

  <script type="text/javascript">
    $(document).ready(function() {
      $('.equal-items').matchHeight();
    });
  </script>

  <script type="text/javascript">
    $(document).ready(function() {
      $('.equal-items-next').matchHeight();
    });
  </script>

  <script src="<?php echo e(asset("sliderengine/amazingslider.js")); ?>"></script>
    
    <script src="<?php echo e(asset("sliderengine/initslider-1.js")); ?>"></script>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>