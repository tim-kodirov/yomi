<?php $__env->startSection('title', '| Новости'); ?>

<?php $__env->startSection('content'); ?>
  
  <p><b>Дата: <?php echo e($date); ?> (<?php echo e($news->count()+$depNews->count()); ?>)</b></p>
  <hr>
  <h1 class = "color-title"><?php echo e(__('app.nav_news')); ?></h1>
  <hr>
  <?php if($news->count() == 0 ): ?>
  <p><b><?php echo e(__('app.no_results')); ?></b></p>
  <?php endif; ?>
  <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <?php echo e(App::isLocale('ru') ? $new->title_ru : $new->title_uz); ?>

    </div>

    <div class="panel-body">
      <div class="row">
        <div class="col-sm-3 text-center overflow-hidden">
          <img src="<?php echo e(asset("images/".$new->image)); ?>" height="100px">
        </div>

        <div class="col-sm-9">
          <?php echo e($new->overview_uz); ?>

          <a href="<?php echo e(route('news.single', $new->slug)); ?>"> <?php echo e(__('app.read_more')); ?> </a>
        </div>
      </div>
    </div>

    <div class="panel-footer">
      <span class="glyphicon glyphicon-calendar"></span> <?php echo e(date('d.m.Y, h:i', strtotime($new->created_at))); ?>

    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <h1 class = "color-title"><?php echo e(__('app.nav_news_dep')); ?></h1>
  <hr>
  <?php if($depNews->count() == 0 ): ?>
  <p><b><?php echo e(__('app.no_results')); ?></b></p>
  <?php endif; ?>
  <?php $__currentLoopData = $depNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <?php echo e(App::isLocale('ru') ? $new->title_ru : $new->title_uz); ?>

    </div>

    <div class="panel-body">
      <div class="row">
        <div class="col-sm-3 text-center overflow-hidden">
          <img src="<?php echo e(asset("images/".$new->image)); ?>" height="100px">
        </div>

        <div class="col-sm-9">
          <?php echo e($new->overview_uz); ?>

          <a href="<?php echo e(route('news.single', $new->slug)); ?>"> <?php echo e(__('app.read_more')); ?> </a>
        </div>
      </div>
    </div>

    <div class="panel-footer">
      <span class="glyphicon glyphicon-calendar"></span> <?php echo e(date('d.m.Y, h:i', strtotime($new->created_at))); ?>

    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>