<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>


<h2 class = "color-title"><?php echo e(__('app.department_managers')); ?></h2>
<hr>
 
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/no_photo.png')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Бобожонов Пулат Раззакович</b></h3>
    <h4>Министр внутренних дел Республики Узбекистан</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Дни прима: </b>Для граждан, желающих записаться на прием к Министру внутренних дел Республики Узбекистан необходимо обратиться с заявлением в Министерство внутренних дел Республики Узбекистан.</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/no_photo.png')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Бобожонов Пулат Раззакович</b></h3>
    <h4>Министр внутренних дел Республики Узбекистан</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Дни прима: </b>Для граждан, желающих записаться на прием к Министру внутренних дел Республики Узбекистан необходимо обратиться с заявлением в Министерство внутренних дел Республики Узбекистан.</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/no_photo.png')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Бобожонов Пулат Раззакович</b></h3>
    <h4>Министр внутренних дел Республики Узбекистан</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Дни прима: </b>Для граждан, желающих записаться на прием к Министру внутренних дел Республики Узбекистан необходимо обратиться с заявлением в Министерство внутренних дел Республики Узбекистан.</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/no_photo.png')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Бобожонов Пулат Раззакович</b></h3>
    <h4>Министр внутренних дел Республики Узбекистан</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Дни прима: </b>Для граждан, желающих записаться на прием к Министру внутренних дел Республики Узбекистан необходимо обратиться с заявлением в Министерство внутренних дел Республики Узбекистан.</h4>
  </div>
</div>
<hr>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

<?php echo $__env->make('partials._department_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
    $('.news-type-select').change(function()
      { 
        var val = $(this).val();
        window.location.replace('/department/2?region='+val);
      });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>