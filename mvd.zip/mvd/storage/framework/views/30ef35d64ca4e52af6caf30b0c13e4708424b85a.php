<?php $__env->startSection('title', '| Фотографии'); ?>

<?php $__env->startSection('styles'); ?>
	<link href="<?php echo e(asset("css/lightbox.css")); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<h1 class = "text-center"><?php echo e(__('app.photos')); ?></h1>
	<hr>
	<div class="row">
		<div class="col-md-8">
			<div class="row">
			<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 photo-index-list">
					<div class = "photo-card">
						<a href = "<?php echo e(asset('images/'.$photo->photo)); ?>" data-lightbox="<?php echo e("image".$photo->id); ?>"><img src="<?php echo e(asset('images/'.$photo->photo)); ?>" alt="<?php echo e(App::isLocale('uz') ? $photo->title_uz : $photo->title_ru); ?>" width = "100%"></a>
						<p class = "info margin-top">
							<?php echo e(__('app.created')); ?>: <span class = "pull-right"><?php echo e(date("d.m.y, H:i", strtotime($photo->created_at))); ?></span>
							<br>
							<?php echo e(__('app.updated')); ?>: <span class = "pull-right"><?php echo e(date("d.m.y, H:i", strtotime($photo->updated_at))); ?></span>
						</p>

						<p class = "text-right">
							<button class = "btn btn-danger btn-sm" data-toggle="modal" data-target="<?php echo e("#myDelete".$photo->id); ?>"><span class = "glyphicon glyphicon-trash"></span></button>

							<div id="<?php echo e("myDelete".$photo->id); ?>" class="modal fade" role="dialog">
							  <div class="modal-dialog">

							    <!-- Modal content-->
							    <div class="modal-content">
							      <div class="modal-header">
							        
							        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
							      </div>
							      <div class="modal-body">
							        <div class="row">
							        	<div class="col-md-6">
							        		<?php echo e(Form::open(['route' => ['photos.destroy', $photo->id ], 'method' => 'DELETE'])); ?>

												<?php echo e(Form::submit( __('app.yes'), ['class' => 'btn btn-block btn-danger'])); ?>

							        		<?php echo e(Form::close()); ?>

							        	</div>
							        	<div class="col-md-6">
							        		<button type="button" class="btn btn-block btn-success" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
							        	</div>
							        </div>
							      </div>
						
							    </div>

							  </div>
							</div>
						</p>
						<h4 class = "text-center">
							<?php echo e(App::isLocale('uz') ? $photo->title_uz : $photo->title_ru); ?>

						</h4>
					</div>
					
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<div class="text-center">
				<?php echo e($photos->links()); ?>

			</div>
		</div>
		<div class="col-md-4">
			<div class = "panel panel-default">
				<div class = "panel-heading text-center">
					<h3 class = "margin"><?php echo e(__('app.create')); ?></h3>
				</div>

				<div class = "panel-body">
					<?php echo e(Form::open(['route' => 'photos.store', 'files' => 'true'])); ?>

						<div class = "form-group">
							<?php echo e(Form::file('image')); ?>

						</div>

						<div class = "form-group">
							<?php echo e(Form::label('title_uz', 'Сарлавха(узб): ', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('title_uz', null, ['class' => 'form-control'])); ?>

							
						</div>

						<div class = "form-group">
							<?php echo e(Form::label('title_ru', 'Заглавие(рус): ', ['class' => 'control-label'])); ?>

							<?php echo e(Form::text('title_ru', null, ['class' => 'form-control'])); ?>

							
						</div>

						<div class = "form-group">
							<?php echo e(Form::submit(__('app.create'), ['class' => 'btn btn-success btn-block'])); ?>

						</div>
					<?php echo e(Form::close()); ?>

				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
	
	<script type="text/javascript">
		
		$("#my-image").hover(function()
			{
				$(this).toggleClass('my-image-hover');
			});

	</script>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>