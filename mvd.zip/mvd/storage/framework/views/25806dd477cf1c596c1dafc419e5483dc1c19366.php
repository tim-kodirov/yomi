<?php $__env->startSection('title', '| Новости'); ?>

<?php $__env->startSection('content'); ?>
	
<div class="pull-right margin-top-20">

	<select name = "isDepartment" class = "news-type-select">
		<option value = "0" <?php echo e($isDepartment ? 'selected' : ''); ?>><?php echo e(__('app.nav_news')); ?></option>
		<option value = "1" <?php echo e($isDepartment ? 'selected' : ''); ?>><?php echo e(__('app.nav_news_dep')); ?></option>
	</select>

	<a href = "<?php echo e(route('news.create')); ?>" class = "btn btn-lg btn-primary"><?php echo e(__('app.create')); ?></a>
</div>

<h1 class = "text-center">
	<?php echo e(__('app.nav_news')); ?>

</h1>
<hr>

<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class = "well">
	<div class = "row">
		
		<div class = "col-md-3 overflow-hidden">
			<div class = "text-center">
				<img src="<?php echo e(asset('images/'.$new->image)); ?>" height="150px">
			</div>
			<p class = "info margin-top">
				<?php echo e(__('app.created')); ?>: <span class = "pull-right"><?php echo e(date('d.m.y, h:i', strtotime($new->created_at))); ?></span>
				</br>
				<?php echo e(__('app.updated')); ?>: <span class = "pull-right"><?php echo e(date('d.m.y, h:i', strtotime($new->updated_at))); ?></span>
				
			</p>
			
		</div>

		<div class = "col-md-8">
			<h4 class = "news-title"><a href="<?php echo e(route('news.show', $new->id)); ?>">
				<?php echo e(App::isLocale('uz') ? $new->title_uz : $new->title_ru); ?>

				</a>
			</h4>
			
		
				<p> 
					<?php echo e(mb_substr(App::isLocale('uz') ? $new->overview_uz : $new->overview_ru, 0, 150+mb_strlen(App::isLocale('uz') ? $new->title_uz : $new->title_ru))); ?> 
					<?php echo e((mb_strlen(App::isLocale('uz') ? $new->overview_uz : $new->overview_ru) > (150+mb_strlen(App::isLocale('uz') ? $new->title_uz : $new->title_ru))) ? '...' : ''); ?> 
				</p> 

			
		</div>


		<div class = "col-md-1 text-right">
			<a href = "<?php echo e(route('news.edit', $new->id)); ?>" class = "btn btn-sm btn-primary"><span class = "glyphicon glyphicon-edit"></span></a>
			<button class = "btn btn-sm btn-danger" data-toggle ="modal" data-target = <?php echo e("#myDelete"."$new->id"); ?>><span class = "glyphicon glyphicon-trash"></span></button>

			<div id=<?php echo e("myDelete"."$new->id"); ?> class="modal fade" role="dialog">
				<div class="modal-dialog">
					
				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title text-center"><?php echo e(__('app.delete')); ?>?</h4>
				      </div>
				      <div class="modal-body">
				      	<div class = "row">
				      		<div class = "col-md-6">
					        	<?php echo Form::open(['route' => ['news.destroy', $new->id ], 'method' => "delete"]); ?>

					        		<?php echo e(Form::submit(__('app.yes'), ['class' => 'btn btn-success btn-large btn-block'])); ?>

					        	<?php echo Form::close(); ?>

					        </div>

					        <div class = "col-md-6">
					        	<button type="button" class="btn btn-danger btn-large btn-block" data-dismiss="modal"><?php echo e(__('app.no')); ?></button>
					        </div>
				      	</div>
				        
				      </div>
				    </div>

				</div>
			</div>
		</div>

	</div>
	
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($news->links()); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$('.news-type-select').change(function()
			{	
				var val = $(this).val();
				window.location.replace('/admin/news?isDepartment='+val);
			});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>