<?php $__env->startSection('title', '| Документы'); ?>

<?php $__env->startSection('content'); ?>


	<h2 class = "color-title"><?php echo e(__('app.nav_documents')); ?></h2>
      <hr>
      
    <!--
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_1')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_2')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_3')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_4')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_5')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_6')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_7')); ?></a></h4>
      <h4><a href="http://lex.uz"><?php echo e(__('app.doc_8')); ?></a></h4>
-->

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>