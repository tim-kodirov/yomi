<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Админ <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Styles -->
	
    <?php echo e(Html::style("css/bootstrap/bootstrap.min.css")); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <div id="app">

        
        <div class="admin-content">
            <?php echo e(Form::open(['route' => 'logout', 'class' => 'pull-right margin-left'])); ?>

                <?php echo e(Form::submit( __('app.exit'), ['class' => 'btn btn-warning'])); ?>

            <?php echo e(Form::close()); ?>


            <?php echo e(Form::open(['route' => 'lang', 'class' => 'pull-right margin-left'])); ?>

              <input type = "hidden" name = "lang" value = "ru"/>
              <button type="submit" class="btn <?php echo e(App::isLocale('ru') ? 'btn-primary' : 'btn-default'); ?>">RU</button>
            <?php echo e(Form::close()); ?>


            <?php echo e(Form::open(['route' => 'lang', 'class' => 'pull-right'])); ?>

              <input type = "hidden" name = "lang" value = "uz"/>
              <button type="submit" class="btn <?php echo e(App::isLocale('uz') ? 'btn-primary' : 'btn-default'); ?>">UZ</button>
            <?php echo e(Form::close()); ?>

        </div>

        <div class = "container-fluid admin-page"> 
			<div class = "row">
				<div class = "col-md-12">
                    
					<ul class = "nav nav-tabs">
						<li class = "<?php echo e(Request::is('admin') ? 'active' : ''); ?>"><a href="/admin"><h4><?php echo e(__('app.nav_main')); ?></h4></a></li>
                        <li class = "<?php echo e(Request::is('admin/news') ? 'active' : ''); ?>"><a href="/admin/news"><h4><?php echo e(__('app.nav_news')); ?></h4></a></li>
						<li class = "<?php echo e(Request::is('admin/photos') ? 'active' : ''); ?>"><a href="/admin/photos"><h4><?php echo e(__('app.photos')); ?></h4></a></li>
                        <li class = "<?php echo e(Request::is('admin/videos') ? 'active' : ''); ?>"><a href="/admin/videos"><h4><?php echo e(__('app.videos')); ?></h4></a></li>
                        <li class = "<?php echo e(Request::is('admin/documents') ? 'active' : ''); ?>"><a href="/admin/documents"><h4><?php echo e(__('app.nav_documents')); ?></h4></a></li>
                        <li class = "<?php echo e(Request::is('admin/wanted') ? 'active' : ''); ?>"><a href="/admin/wanted"><h4><?php echo e(__('app.wanted')); ?></h4></a></li>
                        <li class = "<?php echo e(Request::is('admin/questions') ? 'active' : ''); ?>"><a href="/admin/questions"><h4><?php echo e(__('app.nav_questions')); ?>

                        <?php if($questions_count > 0): ?>
                            <span class = "badge"><?php echo e($questions_count); ?></span>
                        <?php endif; ?>
                        </h4></a></li>
                        <li class = "<?php echo e(Request::is('admin/library') ? 'active' : ''); ?>"><a href="/admin/library"><h4><?php echo e(__('app.library')); ?></h4></a></li>
                        
					</ul>

                    

					<div class = "main-content admin-content">
                        <?php echo $__env->make('admin_partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<?php echo $__env->yieldContent('content'); ?>
					</div>
					
				</div>
			</div>
        </div>
        
    </div>

    <!-- Scripts -->
    <?php echo e(Html::script('js/jquery-3.2.1.min.js')); ?>

    <?php echo e(Html::script('js/bootstrap/bootstrap.min.js')); ?>


    <script>
        /*$('#lang').change(function()
            {   
                $(this).form.submit;
                
            });*/
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>