<?php $__env->startSection('title', '| '.__('app.library')); ?>

<?php $__env->startSection('content'); ?>

  <h1 class = "color-title"><?php echo e(__('app.library')); ?></h1>
  <hr>
  <table class="table">
      <thead>
        <tr>
          <th>№</th>
          <th>Название</th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $libraries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $library): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th><?php echo e($library->id); ?></th>
          <td>
          <img src="<?php echo e(asset('images/'.substr($library->file, strpos($library->file, '.')+1, 3).'.png')); ?>" width = "15px" height="15px">
          <a href="<?php echo e(asset('storage/library/'.$library->file)); ?>"><?php echo e($library->name); ?> </a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <?php echo $libraries->links(); ?>

  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>