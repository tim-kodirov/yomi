<div class="characters">
      <h2 class = "text-center"><?php echo e(__('app.nav_functions')); ?></h2>
</div>
<br>
<div class="row text-center"> 
      <a href="<?php echo e(route('functions', 1)); ?>"><h4><?php echo e(__('app.functions_main')); ?></h4></a>
      <hr>
      <a href="<?php echo e(route('functions', 2)); ?>"><h4><?php echo e(__('app.functions_rights')); ?></h4></a>
      <hr>
      <a href="<?php echo e(route('functions', 3)); ?>"><h4><?php echo e(__('app.functions_articles')); ?></h4></a>
      <hr>
      <a href="<?php echo e(route('functions', 4)); ?>"><h4><?php echo e(__('app.functions_library')); ?></h4></a>
      <hr>
      <a href="<?php echo e(route('functions', 5)); ?>"><h4><?php echo e(__('app.functions_work')); ?></h4></a>
      <hr>
</div>
<hr>