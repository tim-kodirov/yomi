<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>

  <?php echo $__env->make('partials._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="container my-container">
    <?php echo $__env->make('partials._navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="row">

      <div class="col-sm-8 padding">
        <?php echo $__env->yieldContent('content'); ?>
      </div><!-- end of content -->

      <div class="col-sm-4" >
        <?php echo $__env->yieldContent('sidebar'); ?>

        <?php echo $__env->make('partials._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div><!-- end of sidebar-->

    </div><!-- end of main row -->

    <?php echo $__env->yieldContent('additional-content'); ?>
  </div>

  

  <?php echo $__env->make('partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->make('partials._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
</body>
</html>