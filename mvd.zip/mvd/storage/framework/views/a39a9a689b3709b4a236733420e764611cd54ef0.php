<?php $__env->startSection('title', '| '. (App::isLocale('uz') ? $document->title_uz : $document->title_ru)); ?>

<?php $__env->startSection('content'); ?>
	
	<h1 class = "text-center">
		<a href = "<?php echo e(route('documents.index')); ?>" class = "btn btn-large btn-primary pull-left"><span class = "glyphicon glyphicon-arrow-left"></span></a>
		<?php echo e(App::isLocale('uz') ? $document->category->category_uz : $document->category->category_ru); ?>

	</h1>
	<h3 class = "text-center color-title"><?php echo e(App::isLocale('uz') ? $document->title_uz : $document->title_ru); ?></h3>
	<p><?php echo App::isLocale('uz') ? $document->body_uz : $document->body_ru; ?></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>