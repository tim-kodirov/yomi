<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>


<h2 class = "color-title"><?php echo e(__('app.department_managers')); ?></h2>
<hr>
 
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/aktam.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Жалилов Актам Ташназарович</b></h3>
    <h4>Директор</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>7 сентябр 2017 йил</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/alisher.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Юнусов Алишер Бобомурадович</b></h3>
    <h4>Ўқув ишлари бўйича директор ўринбосари</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>16 сентябр 2017 йил</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/Nurali.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Шодиев Нурали Очилович</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси катта ўқитувчиси (0,5)</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>9 сентябр 2017 йил</h4>
  </div>
</div>

<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/axror.png')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Каржанов Аҳрор Рустамович</b></h3>
    <h4>Стратегик бошқарув кафедраси катта ўқитувчиси (0,5)</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>9 сентябр 2017 йил</h4>
  </div>
</div>

<hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/kamoliddin.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Кадыров Камолидин Батирович</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси мудири</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>12 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/gulrux.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Нодирова Гулруҳ Рустамовна</b></h3>
    <h4>Ўқувларни ташкил эьтиш бўлими бошлиғи</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>5 октябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/ilxom.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Маматкулов Илхом Абдурашидович</b></h3>
    <h4>Стратегик бошқарув кафедраси мудири</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>26 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/nargiza.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Норкулова Наргиза Ташпулатовна</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси доценти</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>5 октябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/abdullajon.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Бегматов Абдуллажон Сераджидинович</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси. Профессори (0,25)</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>12 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="<?php echo e(asset('images/managers/sherali.jpg')); ?>" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Рўзиев Шерали Шодиевич</b></h3>
    <h4>Ахборот-таҳлил бўлими бошлиғи</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>21 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

<?php echo $__env->make('partials._department_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
    $('.news-type-select').change(function()
      { 
        var val = $(this).val();
        window.location.replace('/department/2?region='+val);
      });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>