<header id = "my-header">
  <div class="container-fluid">
    <div class="container">
      <div class="row">
        <div class = "col-sm-4">
          <div class="row margin-top-20">
            <?php echo e(Form::open(['route' => 'lang', 'class' => 'pull-left margin-right', 'id' => 'ru-submit'])); ?>

              <input type = "hidden" name = "lang" value = "ru"/>
              <a type = "submit" onclick = "document.getElementById('ru-submit').submit();" class = "<?php echo e(App::isLocale('ru') ? "my-btn-active" : ""); ?> my-btn btn btn-default"><b>Рус</b></a>
            <?php echo e(Form::close()); ?>


            <?php echo e(Form::open(['route' => 'lang', 'class' => 'pull-left', 'id' => 'uz-submit'])); ?>

              <input type = "hidden" name = "lang" value = "uz"/>
              <a type = "submit" onclick = "document.getElementById('uz-submit').submit();" class = "<?php echo e(App::isLocale('uz') ? "my-btn-active" : ""); ?> my-btn btn btn-default"><b>Ўзб</b></a>
            <?php echo e(Form::close()); ?>


          </div><!-- end of ru/uz -->

          <div class = "row margin-top-20">
            <div class="input-group search-group">
              <input type = "text" placeholder="<?php echo e(__('app.search')); ?>..." class = "form-control search"/>
              <div class="input-group-btn">
                <button class="btn btn-default" type="submit">
                  <i class="glyphicon glyphicon-search"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class = "col-sm-4 col-xs-12 text-center">
          <img src="<?php echo e(asset("images/logo.png")); ?>" class = "brand-image" height = "240px">
        </div>

        <div class="col-sm-4">
          <div class="pull-right hidden-xs">
                <h4><span class="glyphicon glyphicon-phone-alt"></span> <?php echo e(__('app.save_service')); ?>: 102</h4>

                <h4><span class="glyphicon glyphicon-earphone"></span> <?php echo e(__('app.trust_call')); ?>: 1102</h4>  
          </div>
        </div>
        
      </div><!-- end of header row-->
    </div>
    <h2 class="text-center"><?php echo __('app.dep_name_part_1'); ?></h2>
    <h1 class = "text-center margin-top-0"> <b><?php echo e(__('app.dep_name_part_2')); ?></b></h1>
    <br>
  </div>
</header><!-- end of header-->

