@extends('layouts.admin')

@section('content')

	<h1 class = "text-center">Админ</h1>
	<p class = "text-center">{{ __('app.welcome') }}</p>

@endsection