<title>MVD @yield('title')</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="{{ asset('css/pignose.calendar.css') }}">

<link rel="stylesheet" type="text/css" href="{{asset("css/style.css")}}">

@yield('styles')