<div class="characters">
      <h3 class = "text-center">{{ __('app.nav_expert') }}</h3>
</div>
<br>
<div class="text-center"> 
      <a href="{{ route('expert', 1) }}"><h4>{{ __('app.expert_main') }}</h4></a>
      <hr>
      <a href="{{ route('expert', 2) }}"><h4>{{ __('app.expert_contact') }}</h4></a>
      <hr>
</div>
