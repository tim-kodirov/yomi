@extends('layouts.main')

@section('title')

@section('content')

<h2 class = "color-title">Эксперт-криминалистика бош бошқармаси</h2>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
     <hr>
        <h4><a href="#">Эксперт-криминалистика бўлинмалари томонидан кўрсатиладиган пуллик хизматлар ва ишлар рўйхати</a></h4>
        
        <i>15-08-2017 &nbsp;&nbsp;|&nbsp;</i>  <span class="glyphicon glyphicon-eye-open" aria-hidden="true"> 40 |
        <strong>Манба:</strong> <a href="">Ўзбекистон Республикаси Ички Ишлар Вазирлиги</a></span>
    
     <br>
     <br>

@endsection


@section('sidebar')

@include('partials._department_sidebar')

@endsection