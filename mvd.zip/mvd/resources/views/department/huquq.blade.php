@extends('layouts.main')

@section('title', ' | Фаолиятнинг хукукий асослари!')

@section('content')

<h2>{{ __('app.department_rights') }}</h2>
<hr>

<div class="my-preserve-data">
@if(App::isLocale('uz'))

@else

@endif
</div>

@endsection

@section('sidebar')
	@include('partials._department_sidebar')
@endsection