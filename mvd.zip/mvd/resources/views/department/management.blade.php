@extends('layouts.main')

@section('title')

@section('content')


<h2 class = "color-title">{{ __('app.department_managers') }}</h2>
<hr>
 
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/aktam.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Жалилов Актам Ташназарович</b></h3>
    <h4>Директор</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>7 сентябр 2017 йил</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/alisher.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Юнусов Алишер Бобомурадович</b></h3>
    <h4>Ўқув ишлари бўйича директор ўринбосари</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>16 сентябр 2017 йил</h4>
  </div>
</div>
<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/Nurali.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Шодиев Нурали Очилович</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси катта ўқитувчиси (0,5)</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>9 сентябр 2017 йил</h4>
  </div>
</div>

<hr>

<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/axror.png') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Каржанов Аҳрор Рустамович</b></h3>
    <h4>Стратегик бошқарув кафедраси катта ўқитувчиси (0,5)</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>9 сентябр 2017 йил</h4>
  </div>
</div>

<hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/kamoliddin.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Кадыров Камолидин Батирович</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси мудири</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>12 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/gulrux.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Нодирова Гулруҳ Рустамовна</b></h3>
    <h4>Ўқувларни ташкил эьтиш бўлими бошлиғи</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>5 октябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/ilxom.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Маматкулов Илхом Абдурашидович</b></h3>
    <h4>Стратегик бошқарув кафедраси мудири</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>26 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/nargiza.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Норкулова Наргиза Ташпулатовна</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси доценти</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>5 октябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/abdullajon.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Бегматов Абдуллажон Сераджидинович</b></h3>
    <h4>Бошқарув психологияси ва лидерлик кафедраси. Профессори (0,25)</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>12 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>
<div class="row">
  <div class="col-sm-4 col-xs-3 text-center">
    <img src="{{ asset('images/managers/sherali.jpg') }}" width = "80%">
  </div>

  <div class="col-sm-8 col-xs-9">
    <h3><b>Рўзиев Шерали Шодиевич</b></h3>
    <h4>Ахборот-таҳлил бўлими бошлиғи</h4>
    <h4><b>Телефон:</b></h4>
    <h4><b>Иш бошлаган вақти: </b>21 сентябр 2017 йил</h4>
  </div>
</div>
  <hr>




@endsection


@section('sidebar')

@include('partials._department_sidebar')
    
@endsection

@section('scripts')
  <script type="text/javascript">
    $('.news-type-select').change(function()
      { 
        var val = $(this).val();
        window.location.replace('/department/2?region='+val);
      });
  </script>
@endsection

